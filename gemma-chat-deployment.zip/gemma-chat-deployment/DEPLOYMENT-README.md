# Gemma Chat App - Deployment Package

## 🚀 One-Line Quick Start

### Linux/macOS:
```bash
./install-and-run.sh
```

### Windows:
```cmd
install-and-run.bat
```

## What This Does
1. Checks Node.js 18+ is installed
2. Runs `npm install` to get dependencies  
3. Starts the chat app at http://localhost:3001
4. Downloads Gemma 270M model on first use (270MB)

## Browser Requirements
- **Chrome Canary** (recommended) with WebGPU flags:
  ```
  --enable-unsafe-webgpu
  --enable-features=WebGPU
  --enable-webgpu-developer-features
  ```
- Or Chrome 113+ with WebGPU enabled

## Manual Installation
If scripts don't work:
```bash
npm install
npm start
```

## First Run
- Model download: 270MB (one-time)
- Model loading: 30-120 seconds first time
- Subsequent loads: 5-15 seconds (cached)
- Memory usage: 400-800MB during chat

## Features
- ✅ Complete privacy (local AI inference)
- ✅ WebGPU acceleration  
- ✅ Real-time token streaming
- ✅ Conversation memory
- ✅ No API keys required

## Troubleshooting
1. **Node.js not found**: Install from https://nodejs.org/
2. **WebGPU errors**: Use Chrome Canary with flags above
3. **Memory issues**: Close other browser tabs
4. **Slow loading**: First model download takes time

## Testing
```bash
npm test              # Run all tests
npm run test:headed   # Debug with Chrome Canary
```

For support: https://github.com/your-repo/gemma-chat-app/issues
