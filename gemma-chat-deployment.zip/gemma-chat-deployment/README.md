# 🌟 Gemma Chat App

A simple browser-based chat application using **Gemma 270M** with **WebGPU** acceleration, **Transformers.js**, and **Web Workers** for a fully local AI chat experience.

## ✨ Features

- 🤖 **Gemma 3 270M ONNX** model running entirely in the browser
- ⚡ **WebGPU acceleration** for fast inference
- 🔄 **Web Workers** for non-blocking model inference
- 💬 **Real-time chat interface** with streaming responses
- 🎯 **Context awareness** - maintains conversation history
- 📱 **Responsive design** with modern UI
- 🔒 **Complete privacy** - no data leaves your device

## 🏗️ Complete System Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         GEMMA CHAT APP - FULL ARCHITECTURE              │
└─────────────────────────────────────────────────────────────────────────┘

                              [User Browser]
                                    │
                    ┌───────────────┴───────────────┐
                    │                               │
              ┌─────▼─────┐                 ┌──────▼──────┐
              │  index.html│                 │  Vite Dev   │
              │    (UI)    │◄────────────────│   Server    │
              │            │  WebSocket/HTTP │  Port 3001  │
              └─────┬─────┘                 └──────┬──────┘
                    │                               │
         ┌──────────┴──────────┐           ┌───────┴───────┐
         │                     │           │   Shutdown    │
    ┌────▼────┐         ┌──────▼─────┐    │   Endpoint    │
    │main.ts  │         │chatManager │    │  /api/shutdown│
    │WebGPU   │◄────────┤   .ts      │    └───────────────┘
    │Detection│         │UI Control  │
    └────┬────┘         └──────┬─────┘
         │                     │
         └──────────┬──────────┘
                    │
         ┌──────────▼──────────┐
         │    Web Worker       │
         │  (modelWorker.ts)   │
         │                     │
         │ ┌─────────────────┐ │
         │ │ Transformers.js │ │
         │ │   Pipeline      │ │
         │ └────────┬────────┘ │
         │          │          │
         │ ┌────────▼────────┐ │
         │ │  Gemma 270M     │ │
         │ │  ONNX Model     │ │
         │ │   (~270MB)      │ │
         │ └────────┬────────┘ │
         └──────────┬──────────┘
                    │
         ┌──────────▼──────────┐
         │      WebGPU API     │
         │  GPU Acceleration   │
         │                     │
         │ • Tensor Operations │
         │ • Matrix Multiply   │
         │ • Attention Layers  │
         └─────────────────────┘

DATA FLOW:
=========
1. User Input → Main Thread → Web Worker Message
2. Web Worker → Transformers.js → ONNX Model Load
3. Model → WebGPU → GPU Compute → Token Generation
4. Streaming Tokens → Web Worker → Main Thread
5. Main Thread → UI Update → User Display

SHUTDOWN FLOW:
=============
1. User clicks Shutdown Button → POST /api/shutdown
2. Express Server → Graceful shutdown → Process exit
3. Alternative: Ctrl+C → SIGINT handler → Clean exit

PERFORMANCE:
===========
• Model Loading: 30-120s (first), 5-15s (cached)
• Token Generation: 10-50 tokens/sec
• Memory Usage: 400-800MB active
• GPU Utilization: Variable by hardware
```

### Core Components:

1. **Main Thread** (`src/main.ts`, `src/chatManager.ts`)
   - UI management and user interactions
   - Chat message display and input handling
   - Progress tracking and error handling

2. **Model Worker** (`src/modelWorker.ts`)
   - Gemma 270M model initialization
   - Text generation with streaming tokens
   - Conversation context management

3. **WebGPU Integration**
   - GPU-accelerated inference via Transformers.js
   - Automatic device detection and fallbacks
   - Memory-efficient processing

## 🚀 Quick Start

### ⚡ One-liner GitHub Execution (Recommended)

Run the app directly from GitHub without cloning:

```bash
# Run immediately from GitHub (requires Chrome Canary with WebGPU)
npx github:kaiser/gemma-chat-app
```

This will:
- ✅ Download the app temporarily  
- ✅ Install all dependencies
- ✅ Start the server at http://localhost:3001
- ✅ Enable WebGPU acceleration automatically

### Prerequisites

- Node.js 18+ 
- **Chrome Canary** with WebGPU support (Chrome 113+)
- ~500MB available RAM for model

### Manual Installation (Alternative)

```bash
# Clone and install
git clone <this-repo>
cd gemma-chat-app
npm install

# Start development server
npm run dev
```

Visit: http://localhost:3001

### Testing

```bash
# Run Playwright tests with WebGPU
npm run test

# Run with headed browser (for debugging)
npm run test:headed
```

## 🎯 WebGPU Setup

### Chrome/Chromium Flags:
For optimal performance, enable these Chrome flags:

```bash
--enable-unsafe-webgpu
--enable-features=WebGPU
--enable-webgpu-developer-features
```

### Browser Compatibility:
- ✅ Chrome 113+ (recommended)
- ✅ Edge 113+
- ⚠️ Firefox (experimental)
- ❌ Safari (not supported)

## 📊 Performance

### Model Loading:
- **First load**: ~30-120 seconds (downloads 270MB model)
- **Subsequent loads**: ~5-15 seconds (cached)

### Response Generation:
- **Typical response**: 2-10 seconds
- **Streaming**: Tokens appear in real-time
- **Memory usage**: ~400-800MB

### Benchmarks:
```
Model: Gemma 3 270M ONNX
Device: WebGPU (varies by GPU)
Tokens/second: 10-50 (depends on hardware)
```

## 🧪 Testing with Playwright

The project includes comprehensive Playwright tests for:

- ✅ WebGPU availability detection
- ✅ Model loading and initialization
- ✅ Chat interaction and streaming
- ✅ Conversation context maintenance
- ✅ Error handling and recovery
- ✅ Performance monitoring

### Test Configuration:

```typescript
// playwright.config.ts
projects: [
  {
    name: 'chrome-webgpu',
    use: { 
      launchOptions: {
        executablePath: '/usr/bin/google-chrome',
        args: [
          '--enable-unsafe-webgpu',
          '--enable-features=WebGPU',
          // ... more WebGPU flags
        ],
      },
    },
  },
]
```

## 📁 Project Structure

```
gemma-chat-app/
├── src/
│   ├── main.ts           # Application entry point
│   ├── chatManager.ts    # Chat logic coordination
│   └── modelWorker.ts    # Web worker for Gemma inference
├── tests/
│   └── gemma-chat.spec.ts # Comprehensive test suite
├── index.html            # Main HTML with embedded CSS
├── vite.config.ts        # Vite configuration
├── playwright.config.ts  # Testing configuration
└── package.json          # Dependencies and scripts
```

## 🔧 Development

### Available Scripts:
```bash
npm run dev         # Start Vite development server
npm run start       # Start server with shutdown endpoint
npm run dev:server  # Alternative server start command
npm run build       # Build for production
npm run preview     # Preview production build
npm run test        # Run Playwright tests

# Convenience scripts
./start-server.sh   # Start server with port check and cleanup
./stop-server.sh    # Stop all server processes on port 3001
```

### Environment Variables:
```bash
# Optional: Custom model endpoint
VITE_MODEL_URL=custom-gemma-model-url
```

## 🎨 Customization

### Modify Model Parameters:
```typescript
// src/modelWorker.ts
const output = await generator(messages, {
  max_new_tokens: 256,    // Response length
  temperature: 0.7,       // Creativity (0-1)
  top_p: 0.95,           // Nucleus sampling
  do_sample: true,       // Enable sampling
});
```

### UI Styling:
The CSS is embedded in `index.html` for simplicity. Key classes:
- `.container` - Main chat container
- `.message` - Chat message styling
- `.user-message` / `.ai-message` - Message types
- `.loading-overlay` - Model loading screen

## 🚨 Troubleshooting

### Common Issues:

**1. WebGPU Not Available:**
```
Error: WebGPU is not supported
Solution: Use Chrome 113+ with WebGPU flags enabled
```

**2. Model Loading Fails:**
```
Error: Failed to load model
Solution: Check network connection, clear browser cache
```

**3. Out of Memory:**
```
Error: GPU memory exceeded
Solution: Close other tabs, reduce max_new_tokens
```

**4. Slow Performance:**
```
Issue: Responses take too long
Solution: Check GPU utilization, disable other GPU apps
```

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

MIT License - feel free to use this project for learning and development!

## 🙏 Acknowledgments

- **HuggingFace Transformers.js** - Browser-based ML inference
- **Google Gemma** - Open language model
- **WebGPU** - GPU acceleration in browsers
- **Vite** - Fast development and build tool
- **Playwright** - Reliable browser testing

## 📈 Project Status

**Current Status**: ✅ **FULLY OPERATIONAL** (Aug 29, 2025)

### Recent Updates:
- ✅ **WebGPU Integration Complete** - Full GPU acceleration working
- ✅ **Comprehensive Testing Suite** - Playwright tests with Chrome Canary WebGPU support
- ✅ **Performance Optimized** - Real-time streaming, Web Workers, memory efficient
- ✅ **Production Ready** - Complete error handling, fallbacks, and user experience
- ✅ **NPX Ready** - One-command GitHub execution via `npx github:kaiser/gemma-chat-app`

### Verification Results:
- **Model Loading**: ✅ Gemma 270M ONNX downloads and initializes correctly
- **WebGPU Detection**: ✅ Automatic GPU availability checking
- **Chat Interface**: ✅ Real-time streaming responses with typing indicators
- **Context Management**: ✅ Multi-turn conversations with history
- **Error Recovery**: ✅ Graceful handling of GPU failures and network issues
- **Memory Management**: ✅ Efficient model loading and cleanup

### Performance Benchmarks:
```
✅ Model Download: ~270MB (one-time)
✅ Initialization: 30-120s first run, 5-15s cached
✅ Response Time: 2-10 seconds with real-time streaming
✅ Memory Usage: 400-800MB during active chat
✅ Token Generation: 10-50 tokens/second (hardware dependent)
✅ Browser Support: Chrome 113+, Edge 113+, Chrome Canary recommended
```

### Development Environment:
- **Server**: http://localhost:3001 (Vite development server)
- **Testing**: Comprehensive Playwright WebGPU test suite
- **Build**: Production-ready Vite build system
- **Dependencies**: HuggingFace Transformers.js 3.0.2, WebGPU acceleration

---

**Built with ❤️ for the browser AI community**

*Ready for production deployment and educational use*