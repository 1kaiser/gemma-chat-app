#!/bin/bash
# Gemma Chat App - One-Line Installer
# Usage: ./install-and-run.sh

set -e

echo "🚀 Gemma Chat App - Quick Start"
echo "=============================="

# Check dependencies
if ! command -v node &> /dev/null; then
    echo "❌ Node.js required. Install from: https://nodejs.org/"
    exit 1
fi

if ! command -v npm &> /dev/null; then
    echo "❌ npm required. Install Node.js from: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js 18+ required. Current: $(node --version)"
    echo "   Download from: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js $(node --version) detected"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Check WebGPU support (optional)
echo "🧪 Checking WebGPU support..."
if command -v google-chrome-canary &> /dev/null || command -v google-chrome &> /dev/null; then
    echo "✅ Chrome detected - WebGPU should work"
else
    echo "⚠️  Chrome/Chrome Canary recommended for WebGPU"
    echo "   Download Chrome Canary: https://www.google.com/chrome/canary/"
fi

# Start the application
echo ""
echo "🌐 Starting Gemma Chat App..."
echo "🎯 Server: http://localhost:3001"
echo "🧠 First model load: 30-120 seconds"
echo "⚡ Cached loads: 5-15 seconds"
echo ""
echo "🖥️  For best performance, use Chrome Canary with flags:"
echo "   --enable-unsafe-webgpu --enable-features=WebGPU"
echo ""
echo "Press Ctrl+C to stop"
echo ""

# Start server
npm start
